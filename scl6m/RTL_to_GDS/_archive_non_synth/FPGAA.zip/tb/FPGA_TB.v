`timescale 1ns/1ps

module FPGA_TB;
    reg CLK100MHZ = 0;
    reg rst = 0;
    wire [15:0] LED;

    integer pass_count = 0;
    integer fail_count = 0;

    // Use simulation clock during simulation and load instructions from tb/instr.mem.
    basys3_top #(
        .USE_SIMULATION_CLOCK(1),
        .IMPLEMENTATION_TOGGLE_COUNT(2),
        .INSTR_MEM_FILE("tb/instr.mem")
    ) uut (
        .CLK100MHZ(CLK100MHZ),
        .rst(rst),
        .LED(LED)
    );

    always #5 CLK100MHZ = ~CLK100MHZ;

    task automatic check_true;
        input cond;
        input [1023:0] msg;
        begin
            if (cond) begin
                pass_count = pass_count + 1;
                $display("PASS: %0s", msg);
            end
            else begin
                fail_count = fail_count + 1;
                $display("FAIL: %0s", msg);
            end
        end
    endtask

    initial begin
        // Hold reset
        rst = 0;
        repeat (3) @(posedge CLK100MHZ);

        // Release reset
        rst = 1;

        // Allow program in tb/instr.mem to execute.
        repeat (30) @(posedge CLK100MHZ);

        // For current tb/instr.mem program:
        // x1=5, x2=9, x3=x1+x2=14, x4=x3-x1=9
        check_true(uut.u_microprocessor0.u_core.u_decodestage.u_regfile0.register[1] == 32'd5,
                   "x1 should be 5 from instr.mem program");
        check_true(uut.u_microprocessor0.u_core.u_decodestage.u_regfile0.register[2] == 32'd9,
                   "x2 should be 9 from instr.mem program");
        check_true(uut.u_microprocessor0.u_core.u_decodestage.u_regfile0.register[3] == 32'd14,
                   "x3 should be 14 from instr.mem program");
        check_true(uut.u_microprocessor0.u_core.u_decodestage.u_regfile0.register[4] == 32'd9,
                   "x4 should be 9 from instr.mem program");

        check_true(LED === 16'h9E95, "LED nibble view should match x4..x1");

        if (fail_count == 0) begin
            $display("RESULT: PASS (%0d checks)", pass_count);
        end
        else begin
            $display("RESULT: FAIL (%0d pass, %0d fail)", pass_count, fail_count);
        end

        $finish;
    end

endmodule
