module instruction_memory #(
    parameter INIT_FILE = ""
) (
    input wire        clk,
    input wire        request,
    input wire [7:0]  address,
    output reg [31:0] data_out
);

    reg [31:0] mem [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1) begin
            mem[i] = 32'h00000013; // NOP default
        end

        if (INIT_FILE != "") begin
            $readmemh(INIT_FILE, mem);
        end
        else begin
            mem[0] = 32'h00500093;
            mem[1] = 32'h00900113;
            mem[2] = 32'h002081B3;
            mem[3] = 32'h40118233;
        end
    end

    always @(*) begin
        if (request) begin
            data_out = mem[address];
        end
        else begin
            data_out = 32'b0;
        end
    end

endmodule
// MODULE_BRIEF: ROM-like instruction storage initialized from file or fallback program.
